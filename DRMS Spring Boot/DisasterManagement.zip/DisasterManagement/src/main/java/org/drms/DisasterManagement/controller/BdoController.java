package org.drms.DisasterManagement.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import lombok.AllArgsConstructor;
import org.drms.DisasterManagement.helper.AuthenticationHelper;
import org.drms.DisasterManagement.model.*;
import org.drms.DisasterManagement.service.BdoService;
import org.drms.DisasterManagement.service.CommonService;
import org.springframework.boot.json.GsonJsonParser;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import java.sql.Time;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;
import java.util.*;

@Controller
@AllArgsConstructor
public class BdoController {
    private CommonService commonService;
    private BdoService bdoService;

    @GetMapping("fir")
    public String getFirPage(Model model, @ModelAttribute("fir") Fir fir) {
        String str = "-1";
        try {
            String username = AuthenticationHelper.getUserDetails(model, commonService);
            if (username != null) {
                model.addAttribute("calamity_list", bdoService.getAllCalamities());
//                model.addAttribute("fir",bdoService.getAllFir().get(1));
                str = "bdo/bdo_fir";
            }
        } catch (Exception e) {
            return "redirect:/?error=" + e.getMessage();
        }
        return str;
    }

    @GetMapping("statement_of_proposal")
    public String getStatementOfProposalPage(Model model) {
        String str = "-1";
        try {
            String username = AuthenticationHelper.getUserDetails(model, commonService);
            if (username != null) {
//                model.addAttribute("fir",bdoService.getAllFir().get(1));
                model.addAttribute("fir_list",bdoService.getDistinctFirNo());
                str = "bdo/bdo_statement_of_proposal";
            }
        } catch (Exception e) {
            return "redirect:/?error=" + e.getMessage();
        }
        return str;
    }

    @GetMapping("gratuitous_relief")
    public String getGratuitousReliefPage(@ModelAttribute("beneficiary") Beneficiary beneficiary, Model model) {
        String str = "-1";
        try {
            String username = AuthenticationHelper.getUserDetails(model, commonService);
            Integer userBlockCode = AuthenticationHelper.getUserBlockCode(model, commonService);
            if (username != null) {
                model.addAttribute("financialyear", getCurrentFinancialYear());
                model.addAttribute("villagelist", bdoService.getVillageFromBlockCode(userBlockCode));
                model.addAttribute("firlist", bdoService.getAllFir());
                model.addAttribute("datelist", bdoService.getAllDatesFromFir());
                model.addAttribute("existingData", bdoService.getAssistedBeneficiaries());
                System.out.println("Ben: " + bdoService.getAssistedBeneficiaries());
                str = "bdo/bdo_gratuitous_relief";
            }
        } catch (Exception e) {
            return "redirect:/?error=" + e.getMessage();
        }
        return str;
    }

    @RequestMapping(value = "/getexgratiafromfir.htm", method = RequestMethod.GET)
    @ResponseBody
    public List<Map<String, Object>> getexgratiafromfir(Model model, @RequestParam String firNo) {
        List<Map<String, Object>> tableData = new ArrayList<>();
//        JSONArray requireddocs = new JSONArray();
        String added = "";
        try {
            String username = AuthenticationHelper.getUserDetails(model, commonService);
            if (username != null) {
                List<T_exgratia_form> exgratiaForms = edao.getExgratiaFormsByFir(firNo);

                for (T_exgratia_form form : exgratiaForms) {
                    Map<String, Object> row = new HashMap<>();
                    List<Map<String, Object>> requireddocs = new ArrayList<>();
                    String assistance = form.getNorm_code().getDescription() + " " + form.getNorm_code().getLosstype() + " ";

                    String option = form.getNorm_code().getOption();
                    String formattedOption = (option != null && !option.equalsIgnoreCase("N.A") && !option.equalsIgnoreCase("NA")) ? option : "";

                    assistance += formattedOption;

                    List<Object[]> doclist = edao.getRequiredDocsListByNormcode(form.getNorm_code().getNorm_code());

                    for (Object[] objects : doclist) {
                        if (added.contains(objects[0].toString())) {
                        } else {
                            Map<String, Object> doc = new HashMap<>();
                            doc.put("documentid", objects[0]);
                            doc.put("document_name", objects[1]);
                            requireddocs.add(doc);
                            added += "," + objects[0].toString();
                        }
                    }

                    row.put("beneficiaryName", form.getBeneficiary_id().getBeneficiary_name());
                    row.put("village", form.getBeneficiary_id().getVillagecode().getVillagename());
                    row.put("amount", form.getAmount());
                    row.put("assistance", assistance);
                    row.put("remarks", form.getRemarks());
                    String reportid = form.getReportid() != null ? form.getReportid().getReportid() : "";
                    row.put("reportid", reportid);
                    tableData.add(row);
                }
                tableData.add("requireddocs", requireddocs);

            }
        } catch (Exception e) {
            System.out.println("Error retrieving table data: " + e.toString());
        }
        return tableData;
    }


//    @GetMapping("fir")
//    public ModelAndView getFirPage(Model model) {
//        ModelAndView mv = new ModelAndView("bdo/bdo_fir");
//        try {
//            String username = AuthenticationHelper.getUserDetails(model, commonService);
//            if (username != null) {
//                mv.addObject("calamity_list", bdoService.getAllCalamities());
//            }
//        } catch (Exception e) {
//            mv.addObject("Error: "+e.getMessage());
//        }
//        return mv;
//    }

    @GetMapping("getAllInfrastructures")
    @ResponseBody
    public List<M_infrastructure> getAllInfrastructures() {
        return bdoService.getAllInfrastructures();
    }

    @PostMapping("savefir")
    @ResponseBody
    public ResponseEntity<String> saveFir(@ModelAttribute("fir") Fir fir,
                                          @RequestParam("time_occurrence") String timeOccurrence,
                                          @RequestParam("photos") MultipartFile[] files,
                                          @RequestParam("userid") String userid,
                                          @RequestParam("blockcode") String blockcode,
                                          @RequestParam(value = "infrastructure[]", required = false) String[] infrastructures,
                                          @RequestParam(value = "damagedInfra[]", required = false) String[] damagedInfra, Model model) {
        String res = "-1";
        String prop = "-1";
        String doc = "-1";
        try {
            String username = AuthenticationHelper.getUserDetails(model, commonService);
            if (username != null) {
                // Parse timeOccurrence to java.sql.Time
                SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");
                Date parsedDate = timeFormat.parse(timeOccurrence);
                Time time = new Time(parsedDate.getTime());
                MT_Userlogin userlogin = new MT_Userlogin();
                userlogin.setUserid(userid);
                M_block mBlock = new M_block();
                mBlock.setBlockcode(Integer.parseInt(blockcode));
                //Set the time and logdate in the Fir object
                fir.setTime_of_calamity_occurence(time);
                fir.setLogdate(new Date());
                fir.setUserid(userlogin);
                fir.setBlockcode(mBlock);
                res = bdoService.saveFir(fir);

                if (!res.equals("-1")) {
                    // Check if infrastructure and damagedInfra arrays have data
                    if (infrastructures != null && damagedInfra != null && infrastructures.length == damagedInfra.length) {
                        for (int i = 0; i < infrastructures.length; i++) {
                            String infrastructureid = infrastructures[i];
                            int totalDamage = Integer.parseInt(damagedInfra[i]);

                            M_infrastructure mInfrastructure = new M_infrastructure();
                            mInfrastructure.setInfrastructure_id(Integer.parseInt(infrastructureid));

                            T_property_damaged tPropertyDamaged = new T_property_damaged();
                            tPropertyDamaged.setInfrastructure_id(mInfrastructure);
                            tPropertyDamaged.setTotal_damage(totalDamage);
                            tPropertyDamaged.setFir_no(fir);
                            //Save Damaged Infrastructures
                            prop = bdoService.savePropertyDamaged(tPropertyDamaged);
                        }
                    }

                    //Save FIR Multiple Documents
                    for (MultipartFile file : files) {
                        if (!file.isEmpty()) {
                            Document_fir documentFir = new Document_fir();
                            documentFir.setDocumentname(file.getOriginalFilename());
                            documentFir.setFiletype(file.getContentType());
                            documentFir.setFilestored(file.getBytes());
                            documentFir.setFir_no(fir);
                            System.out.println("File Name: " + file.getOriginalFilename());
                            //Save Document FIR
                            doc = bdoService.saveDocumentFir(documentFir);
                        }
                    }
                    return ResponseEntity.ok(res);
                }
            }
        } catch (Exception e) {
            System.out.println("BdoController|saveFir: " + e.toString());
        }
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("-1");
    }

//    @GetMapping("getallfirfromdate")
//    @ResponseBody
//    public List<Fir> getAllFirFromDate(@RequestParam("date") String dateString){
//        String res = "-1";
//        List<Fir> firList = null;
//        try {
//            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
//            Date date = dateFormat.parse(dateString);
//
//            firList = bdoService.getAllFirFromDate(date);
//        }catch (Exception e){
//            System.out.println("BdoController|getAllFirFromDate: "+e.toString());
//        }
//        return firList;
//    }

    @GetMapping("getallfirfromdate")
    public ResponseEntity<List<Fir>> getAllFirFromDate(@RequestParam("date") String dateString) {
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            Date date = dateFormat.parse(dateString);

            List<Fir> firList = bdoService.getAllFirFromDate(date);
            System.out.println("firList: " + firList.toString());

            return ResponseEntity.ok(firList);
        } catch (Exception e) {
            System.out.println("BdoController|getAllFirFromDate: " + e.toString());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    @GetMapping("exgratianorms")
    public ResponseEntity<List<Norms>> getExgratiaNorms(Model model) {
        try {
            List<Norms> normsList = bdoService.getExgratiaNorms();
            return ResponseEntity.ok(normsList);
        } catch (Exception e) {
            System.out.println("BdoController|getExgratiaNorms: " + e.toString());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    @GetMapping("getdocumenttypesforbeneficiary")
    public ResponseEntity<List<String>> getDocumentTypeForBeneficiary(Model model, @RequestParam("norm_code") String norm_code) {
        try {
            List<String> docList = bdoService.getDocumentTypeByNormCode(Integer.parseInt(norm_code));
            return ResponseEntity.ok(docList);
        } catch (Exception e) {
            System.out.println("BdoController|getDocumentTypeForBeneficiary: " + e.toString());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    @PostMapping("saveexgratia")
    public ResponseEntity<String> saveExgratia(
            Model model,
            @ModelAttribute("beneficiary") Beneficiary beneficiary,
            @RequestParam("fir_no") String fir_no,
            @RequestParam("files") MultipartFile[] files,
            String age_category,
            String gender,
            @RequestParam("fin_year") String fin_year,
            @RequestParam("normSelect") String normSelect,
            String amountpayable,
            String remarks) {
        String res = "-1";
        String tef = "-1";
        try {
            String username = AuthenticationHelper.getUserDetails(model, commonService);
            String userid = AuthenticationHelper.getUserid(model, commonService);
            if (username != null){
                beneficiary.setAge_category(age_category);
                beneficiary.setGender(gender);
                res = bdoService.saveExgratiaBeneficiary(beneficiary);
                if (!res.equals("-1")){
                    //Save in T_exgratia_form
                    T_exgratia_form tExgratiaForm = new T_exgratia_form();
                    M_calamity mCalamity = bdoService.getCalamityByFir(fir_no);
                    tExgratiaForm.setBeneficiary_id(beneficiary);
                    tExgratiaForm.setFin_year(fin_year);
                    Fir fir = new Fir();
                    fir.setFir_no(fir_no);
                    tExgratiaForm.setFir_no(fir);
                    tExgratiaForm.setLogdate(new Date());
                    Norms norms = new Norms();
                    norms.setNorm_code(Integer.parseInt(normSelect));
                    tExgratiaForm.setNorm_code(norms);
                    tExgratiaForm.setRemarks(remarks);
                    tExgratiaForm.setAmount(Integer.parseInt(amountpayable));
                    MT_Userlogin userlogin = new MT_Userlogin();
                    userlogin.setUserid(userid);
                    tExgratiaForm.setUserid(userlogin);
                    tExgratiaForm.setCalamity_id(mCalamity);
                    tef = bdoService.saveBeneficiaryExgratia(tExgratiaForm);
                }

                //save multiple files
                for (MultipartFile file : files) {
                    if (!file.isEmpty()) {
                        Document_beneficiary documentBeneficiary = new Document_beneficiary();
                        documentBeneficiary.setDocumentname(file.getOriginalFilename());
                        documentBeneficiary.setFiletype(file.getContentType());
                        documentBeneficiary.setFilestored(file.getBytes());
                        documentBeneficiary.setBeneficiary_id(beneficiary);
                        //Save Document Beneficiary
                        bdoService.saveDocumentBeneficiary(documentBeneficiary);
                    }
                }
                return ResponseEntity.ok(res);
            }
        } catch (Exception e) {
            System.out.println("BdoController|saveExgratiaForm: " + e.toString());
        }
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("-1");
    }


    /*----------------------Local Functions--------------------------*/
    public String getCurrentFinancialYear() {
        LocalDate currentDate = LocalDate.now();
        int currentYear = currentDate.getYear();
        int currentMonth = currentDate.getMonthValue();
        int financialYearStartMonth = Month.APRIL.getValue();
        int financialYear;
        if (currentMonth >= financialYearStartMonth) {
            financialYear = currentYear;
        } else {
            financialYear = currentYear - 1;
        }
        int nextYear = financialYear + 1;
        return financialYear + "-" + nextYear;
    }
}
