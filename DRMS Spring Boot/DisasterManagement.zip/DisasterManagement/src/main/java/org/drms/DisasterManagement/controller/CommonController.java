package org.drms.DisasterManagement.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("drms")
public class CommonController {
	
	@GetMapping("/")
    public String index() {
        // This method maps the root URL ("/") to index.html
        return "index";
    }
	
//	@GetMapping("login")
//	public String login(Model model) {
//		MT_Userlogin userlogin = new MT_Userlogin();
//		model.addAttribute("userlogin",userlogin);
//		return "login";
//	}
	
}
