package org.drms.DisasterManagement.controller;

import org.drms.DisasterManagement.helper.AuthenticationHelper;
import org.drms.DisasterManagement.service.CommonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {
    @Autowired
    private CommonService commonService;

    @GetMapping("home")
    public String getHome(Model model) {
        String str = "/login";
        try {
            String username = AuthenticationHelper.getUserDetails(model, commonService);
            String role_code = AuthenticationHelper.getUserRoleCode(model, commonService);
//            System.out.println("role_code: "+role_code);
            if (username != null) {
                switch (role_code){
                    case "1" :
                        model.addAttribute("username",username);
                        str = "super_home";
                        break;
                    case "2" :
                        model.addAttribute("username",username);
                        str = "admin/admin_home";
                        break;
                    case "3" :
                        model.addAttribute("username",username);
                        str = "dc/dc_home";
                        break;
                    case "4" :
                        model.addAttribute("username",username);
                        model.addAttribute("role_code", role_code);
                        str = "bdo/bdo_home";
                        break;
                }
            }else {
                model.addAttribute("msg", "Invalid Login / Session Expired. Please Login Again");
                return "/login";
            }
        } catch (Exception e) {
            return "redirect:/?error=" + e.getMessage();
        }
        return str;
    }
}
