package org.drms.DisasterManagement.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("test")
public class IndexController {

	@GetMapping("/")
    public String index() {
        // This method maps the root URL ("/") to index.html
        return "index.html";
    }
}
