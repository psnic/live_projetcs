package org.drms.DisasterManagement.controller;


import org.drms.DisasterManagement.helper.CaptchaHelper;
import org.drms.DisasterManagement.model.MT_Userlogin;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class LoginController {
	
	@GetMapping("/login")
	public String login(Model model) {
		MT_Userlogin userlogin = new MT_Userlogin();
		CaptchaHelper.getCaptcha(userlogin);
		model.addAttribute("userlogin", userlogin);
		return "login.html";
	}
	
	@ResponseBody
	@GetMapping("/refresh-captcha")
	public MT_Userlogin refreshCaptcha() {
		MT_Userlogin userlogin = new MT_Userlogin();
		CaptchaHelper.getCaptcha(userlogin);
		return userlogin;
	}
}
