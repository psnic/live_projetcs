//package org.drms.DisasterManagement.controller;
//
//
//import org.drms.DisasterManagement.helper.AuthenticationHelper;
//import org.drms.DisasterManagement.service.CommonService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
//
//@Controller
////@RequestMapping("super")
//public class SuperUserController {
//
//	@Autowired
//	private CommonService commonService;
//
//	@GetMapping("home")
//	public String getHome(Model model) {
//		try {
//			String username = AuthenticationHelper.getUserDetails(model, commonService);
//			String role_code = AuthenticationHelper.getUserRoleCode(model, commonService);
//			System.out.println("role_code: "+role_code);
//			if (username != null) {
//				return "home";
//			}
//			return "/login";
//		} catch (Exception e) {
//			return "redirect:/?error=" + e.getMessage();
//		}
//	}
//}
