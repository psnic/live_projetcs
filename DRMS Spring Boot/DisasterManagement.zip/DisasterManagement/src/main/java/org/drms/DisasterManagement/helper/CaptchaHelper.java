package org.drms.DisasterManagement.helper;

import cn.apiclub.captcha.Captcha;
import org.drms.DisasterManagement.config.CaptchaUtil;
import org.drms.DisasterManagement.model.MT_Userlogin;


public class CaptchaHelper {
    
    public static void getCaptcha(MT_Userlogin userlogin) {
      try {
          Captcha captcha = CaptchaUtil.createCaptcha(300, 75);
          userlogin.setHiddenCaptcha(captcha.getAnswer());
          userlogin.setCaptcha(""); // value entered by the User
          userlogin.setRealCaptcha(CaptchaUtil.encodeCaptcha(captcha));
      } catch (Exception e) {
          throw new RuntimeException("Captcha cannot be generated!");
      }

  }
}
