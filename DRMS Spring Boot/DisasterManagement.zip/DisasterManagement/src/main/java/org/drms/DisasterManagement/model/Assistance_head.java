package org.drms.DisasterManagement.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table(name = "assistance_head", schema = "drms")
@NoArgsConstructor
@AllArgsConstructor
public class Assistance_head {
    @Id
    private String assistance_head_code;
    private String description;
    private String sub_window;
}
