package org.drms.DisasterManagement.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table(name = "beneficiary", schema = "drms")
@NoArgsConstructor
@AllArgsConstructor
public class Beneficiary {
    @Id
    private String beneficiary_id;
    private String beneficiary_name;
    private String victim_name;
    private String ifsc;
    private String branch_name;
    private String bank_name;
    private String ac_number;
    private String age_category;
    private String gender;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "villagecode")
    private M_village villagecode;
}
