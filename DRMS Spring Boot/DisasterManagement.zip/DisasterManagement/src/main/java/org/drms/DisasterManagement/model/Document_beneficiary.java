package org.drms.DisasterManagement.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table(name = "document_beneficiary", schema = "drms")
@NoArgsConstructor
@AllArgsConstructor
public class Document_beneficiary {
    @Id
    private String bdocumentcode;
    private String documentname;
    private String description;
    private byte[] filestored;
    private String filetype;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "beneficiary_id")
    private Beneficiary beneficiary_id;
}
