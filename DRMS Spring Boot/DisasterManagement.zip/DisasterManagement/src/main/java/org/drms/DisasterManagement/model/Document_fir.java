package org.drms.DisasterManagement.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

@Entity
@Data
@Table(name = "document_fir", schema = "drms")
@AllArgsConstructor
@NoArgsConstructor
public class Document_fir {
    @Id
    private String documentcode;
    private String documentname;
    private String description;
    private byte[] filestored;
    private String filetype;
    @ManyToOne
    @JoinColumn(name = "fir_no")
    private Fir fir_no;
}
