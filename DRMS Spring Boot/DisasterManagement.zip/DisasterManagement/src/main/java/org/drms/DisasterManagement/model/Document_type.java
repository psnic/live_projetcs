package org.drms.DisasterManagement.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table(name = "document_type", schema = "drms")
@NoArgsConstructor
@AllArgsConstructor
public class Document_type {
    @Id
    private int documentcode;
    private String description;
    private String document_name;
    private Boolean is_specific;
}
