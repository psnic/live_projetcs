package org.drms.DisasterManagement.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Data
@Entity
@Table(name = "fir", schema = "drms")
@NoArgsConstructor
@AllArgsConstructor
//@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Fir {
    @Id
    private String fir_no;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "calamity_id")
    private M_calamity calamity_id;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "blockcode")
    private M_block blockcode;
    @Temporal(TemporalType.DATE)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date date_of_calamity_occurence;
    @Temporal(TemporalType.TIMESTAMP)
    private Date time_of_calamity_occurence;
    private int no_villages_affected;
    private int human_population_affected;
    private int people_dead;
    private int people_missing;
    private int people_injured;
    private int animals_dead;
    private int animals_lost;
    private int animals_affected;
    private String crop_affected;
    private int house_fully;
    private int house_partially;
    private String relief_measure;
    private String immediate_response;
    private String forecast;
    private String other_info;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "userid", referencedColumnName = "userid")
    private MT_Userlogin userid;
    @Temporal(TemporalType.DATE)
    private Date logdate;
}
