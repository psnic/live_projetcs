package org.drms.DisasterManagement.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table(name = "lossnorm_document", schema = "drms")
@NoArgsConstructor
@AllArgsConstructor
public class Lossnorm_Document {
    @Id
    @ManyToOne
    @JoinColumn(name = "norm_code")
    private Norms norm_code;

    @Id
    @ManyToOne
    @JoinColumn(name = "documentcode")
    private Document_type documentcode;
}
