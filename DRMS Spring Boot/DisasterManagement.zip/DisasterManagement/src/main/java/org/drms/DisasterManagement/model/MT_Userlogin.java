package org.drms.DisasterManagement.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@Entity
@Table(name = "mt_userlogin", schema = "drms")
@NoArgsConstructor
@AllArgsConstructor
public class MT_Userlogin {
    
    @Id
    private String userid;
    private String username;
    private String password;

    @OneToOne
    @JoinColumn(name = "role_code")
    private M_userroles role_code;

    @ManyToOne
    @JoinColumn(name = "blockcode")
    private M_block blockcode;

    @Temporal(TemporalType.DATE)
    private Date lastlogin;

    @Temporal(TemporalType.DATE)
    private Date entrydate;
    private String usercode;
    
    @Transient
	private String captcha;

	@Transient
	private String hiddenCaptcha;

	@Transient
	private String realCaptcha;

//
}

