package org.drms.DisasterManagement.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "m_block", schema = "drms")
public class M_block {
    
    @Id
    private int blockcode;
    
    private String blockname;
    
    @ManyToOne
    @JoinColumn(name = "districtcodelgd")
    private M_districts districtcodelgd;


}
