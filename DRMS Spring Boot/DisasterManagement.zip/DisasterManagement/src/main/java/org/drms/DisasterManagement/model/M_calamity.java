package org.drms.DisasterManagement.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

@Data
@Entity
@Table(name = "m_calamity", schema = "drms")
@NoArgsConstructor
@AllArgsConstructor
public class M_calamity {
    @Id
    private String calamity_id;

    private String calamity_name;
}
