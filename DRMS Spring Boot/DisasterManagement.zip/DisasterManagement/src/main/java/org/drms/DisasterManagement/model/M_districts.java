package org.drms.DisasterManagement.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "m_districts", schema = "drms")
public class M_districts {
    
    @Id
    private String districtcodelgd;
    
    private String districtname;
    
    private String districtshortname;

}
