package org.drms.DisasterManagement.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;
@Data
@Entity
@Table(name = "m_infrastructure", schema = "drms")
@NoArgsConstructor
@AllArgsConstructor
public class M_infrastructure {
    @Id
    public Integer infrastructure_id;
    public String infrastructure_name;
}
