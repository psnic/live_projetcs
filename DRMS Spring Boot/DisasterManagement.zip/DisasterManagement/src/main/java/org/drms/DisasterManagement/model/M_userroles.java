package org.drms.DisasterManagement.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "m_userroles", schema = "drms")
public class M_userroles {

    @Id
    private String role_code;
    
    private String role_name;
    
    private String role_description;
    
    @Temporal(TemporalType.DATE)
    private Date entrydate;

}

