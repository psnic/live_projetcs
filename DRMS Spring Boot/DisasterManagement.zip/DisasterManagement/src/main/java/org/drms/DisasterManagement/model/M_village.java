package org.drms.DisasterManagement.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table(name = "m_village", schema = "drms")
@NoArgsConstructor
@AllArgsConstructor
public class M_village {
    @Id
    private String villagecode;

    private String villagename;
    @ManyToOne
    @JoinColumn(name = "blockcode")
    private M_block blockcode;
    @ManyToOne
    @JoinColumn(name = "districtcodelgd")
    private M_districts districtcodelgd;
}
