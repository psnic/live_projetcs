package org.drms.DisasterManagement.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Collection;
import java.util.Collections;
import java.util.Set;

@Data
@Entity
@Table(name = "norms", schema = "drms")
@NoArgsConstructor
@AllArgsConstructor
public class Norms {
    @Id
    private int norm_code;

    private String description;

    private String losstype;

    private String option;

    private int value;
    private int minimum_value;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "assistance_head_code")
    private Assistance_head assistance_head_code;
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "lossnorm_document",
            joinColumns = @JoinColumn(name = "norm_code"),
            inverseJoinColumns = @JoinColumn(name = "documentcode"))
    private Set<Document_type> doctype = Collections.<Document_type>emptySet();
}
