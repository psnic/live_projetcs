package org.drms.DisasterManagement.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table(name = "proposal", schema = "drms")
@NoArgsConstructor
@AllArgsConstructor
public class Proposal {
    @Id
    private String proposalid;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "blockcode")
    private M_block blockcode;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "statuscode")
    private M_status statuscode;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "userid")
    private MT_Userlogin userid;
}
