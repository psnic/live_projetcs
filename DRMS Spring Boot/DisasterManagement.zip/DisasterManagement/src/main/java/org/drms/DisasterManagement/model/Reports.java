package org.drms.DisasterManagement.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table(name = "reports", schema = "drms")
@NoArgsConstructor
@AllArgsConstructor
public class Reports {
    @Id
    private String reportid;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "blockcode")
    private M_block blockcode;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "statuscode")
    private M_status statuscode;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "proposalid")
    private Proposal proposalid;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "userid")
    private MT_Userlogin userid;
    private String no_of_population_affected;
    private String no_of_family_affected;
    private String no_of_village_affected;
    private String remarks;
}
