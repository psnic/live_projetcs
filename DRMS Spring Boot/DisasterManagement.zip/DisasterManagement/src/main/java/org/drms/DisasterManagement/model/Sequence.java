package org.drms.DisasterManagement.model;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

@Entity
@Data
@Table(name = "sequence", schema = "drms")
@AllArgsConstructor
@NoArgsConstructor
public class Sequence {
    @Id
    private String sequenceid;
    private int startseq;
    private int endseq;
    private String pattern;
}
