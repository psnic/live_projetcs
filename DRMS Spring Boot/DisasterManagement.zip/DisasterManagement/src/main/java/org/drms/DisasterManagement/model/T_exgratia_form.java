package org.drms.DisasterManagement.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@Entity
@Table(name = "t_exgratia_form", schema = "drms")
@NoArgsConstructor
@AllArgsConstructor
public class T_exgratia_form {
    @Id
    private String t_exgratia_form_id;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "beneficiary_id")
    private Beneficiary beneficiary_id;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "fir_no")
    private Fir fir_no;
    private int amount;
    private String remarks;
    private String fin_year;
    @Temporal(TemporalType.DATE)
    private Date logdate;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "userid")
    private MT_Userlogin userid;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "norm_code")
    private Norms norm_code;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "reportid")
    private Reports reportid;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "calamity_id")
    private M_calamity calamity_id;
}
