package org.drms.DisasterManagement.model;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

@Entity
@Data
@Table(name = "t_property_damaged", schema = "drms")
@AllArgsConstructor
@NoArgsConstructor
public class T_property_damaged {
    @Id
    private String property_damage_id;
    @ManyToOne
    @JoinColumn(name = "infrastructure_id")
    private M_infrastructure infrastructure_id;
    private int total_damage;
    @ManyToOne
    @JoinColumn(name = "fir_no")
    private Fir fir_no;
}
