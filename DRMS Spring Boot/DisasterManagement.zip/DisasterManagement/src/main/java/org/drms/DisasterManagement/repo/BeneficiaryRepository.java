package org.drms.DisasterManagement.repo;

import org.drms.DisasterManagement.model.Beneficiary;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface BeneficiaryRepository extends JpaRepository<Beneficiary, String> {
    @Query(value = "SELECT b.\"beneficiary_name\", n.\"description\", n.\"losstype\", n.\"option\", t.\"amount\"\n" +
            "FROM \"drms\".\"beneficiary\" b\n" +
            "JOIN \"drms\".\"t_exgratia_form\" t ON b.\"beneficiary_id\" = t.\"beneficiary_id\"\n" +
            "JOIN \"drms\".\"norms\" n ON t.\"norm_code\" = n.\"norm_code\"\n WHERE t.\"reportid\" IS NULL", nativeQuery = true)
    public List<Object[]> getAssistedBeneficiaries();
}
