package org.drms.DisasterManagement.repo;

import org.drms.DisasterManagement.model.M_calamity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CalamityRepository extends JpaRepository<M_calamity, String> {
}
