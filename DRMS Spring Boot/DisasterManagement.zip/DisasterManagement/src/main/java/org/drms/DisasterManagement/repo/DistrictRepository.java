package org.drms.DisasterManagement.repo;

import org.drms.DisasterManagement.model.M_districts;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface DistrictRepository extends JpaRepository<M_districts, String> {
    @Query("SELECT d.districtshortname FROM M_districts d JOIN M_block b ON d.districtcodelgd = b.districtcodelgd.districtcodelgd WHERE b.blockcode = :blockcode")
    public String getDistrictShortNameByBlockCode(int blockcode);
}
