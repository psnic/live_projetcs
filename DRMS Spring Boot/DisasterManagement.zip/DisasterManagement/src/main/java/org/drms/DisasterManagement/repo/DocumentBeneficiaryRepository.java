package org.drms.DisasterManagement.repo;

import org.drms.DisasterManagement.model.Document_beneficiary;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DocumentBeneficiaryRepository extends JpaRepository<Document_beneficiary, String> {
}
