package org.drms.DisasterManagement.repo;

import org.drms.DisasterManagement.model.Document_fir;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DocumentFirRepo extends JpaRepository<Document_fir, String> {
}
