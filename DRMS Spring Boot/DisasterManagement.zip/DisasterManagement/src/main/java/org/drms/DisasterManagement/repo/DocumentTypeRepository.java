package org.drms.DisasterManagement.repo;

import org.drms.DisasterManagement.model.Document_type;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface DocumentTypeRepository extends JpaRepository<Document_type, Integer> {
//    @Query(value = "SELECT LOWER(dt.document_name) FROM document_type " +
//            "dt JOIN lossnorm_document ld ON dt.documentcode = ld.documentcode " +
//            "JOIN norms en ON ld.norm_code = en.norm_code " +
//            "WHERE en.norm_code = :norm_code AND dt.is_specific = true", nativeQuery = true)
//    public List<Document_type> getDocumentsByNormCode(@Param("norm_code") int norm_code);

    @Query("SELECT LOWER(dt.document_name) FROM Document_type dt " +
            "JOIN Lossnorm_Document ld ON dt.documentcode = ld.documentcode.documentcode " +
            "JOIN Norms en ON ld.norm_code.norm_code = en.norm_code " +
            "WHERE en.norm_code = :norm_code AND dt.is_specific = true")
    public List<String> getDocumentsByNormCode(@Param("norm_code") int norm_code);
}
