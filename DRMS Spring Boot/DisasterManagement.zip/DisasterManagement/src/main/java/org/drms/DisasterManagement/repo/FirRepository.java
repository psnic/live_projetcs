package org.drms.DisasterManagement.repo;

import org.drms.DisasterManagement.model.Fir;
import org.drms.DisasterManagement.model.M_calamity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public interface FirRepository extends JpaRepository<Fir, String> {
    @Query("SELECT DISTINCT f.date_of_calamity_occurence FROM Fir f")
    List<Date> getAllDistinctCalamityOccurrenceDates();

    @Query("SELECT f FROM Fir f WHERE f.date_of_calamity_occurence = :date")
    List<Fir> getAllFirFromDate(@Param("date") Date date);

    @Query("SELECT DISTINCT calamity_id from Fir WHERE fir_no = :fir_no")
    M_calamity getCalamityByFir(@Param("fir_no")String fir_no);

    @Query("SELECT DISTINCT e.fir_no FROM T_exgratia_form e WHERE e.reportid IS NULL")
    List<Fir> getDistinctFirNo();

//    public default List<String> getAllDistinctCalamityOccurrenceDatesAsString() {
//        List<Date> dates =getAllDistinctCalamityOccurrenceDates();
//        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
//
//        return dates.stream()
//                .map(date -> dateFormat.format(date))
//                .toList();
//    }
}
