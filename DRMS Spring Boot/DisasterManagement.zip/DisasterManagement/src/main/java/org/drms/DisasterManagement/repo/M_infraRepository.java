package org.drms.DisasterManagement.repo;

import org.drms.DisasterManagement.model.M_infrastructure;
import org.springframework.data.jpa.repository.JpaRepository;

public interface M_infraRepository extends JpaRepository<M_infrastructure, Integer> {
}
