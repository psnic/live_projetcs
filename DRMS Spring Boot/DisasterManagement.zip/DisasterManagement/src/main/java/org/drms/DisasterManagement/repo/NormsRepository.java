package org.drms.DisasterManagement.repo;

import org.drms.DisasterManagement.model.Norms;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface NormsRepository extends JpaRepository<Norms, Integer> {
        @Query("SELECT n FROM Norms n WHERE n.assistance_head_code.assistance_head_code = 'AH-GR' " +
                "ORDER BY n.norm_code")
        public List<Norms> getAllExgratiaNorms();

//        @Query("SELECT DISTINCT n.norm_code, n.description, n.losstype, n.option, n.value, " +
//                "n.minimum_value, n.assistance_head_code FROM Norms n WHERE " +
//                "n.assistance_head_code.assistance_head_code = 'AH-GR' ORDER BY n.norm_code")
//        public List<Norms> getAllExgratiaNorms();


}
