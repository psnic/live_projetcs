package org.drms.DisasterManagement.repo;

import jakarta.transaction.Transactional;
import org.drms.DisasterManagement.model.Sequence;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface SequenceRepository extends JpaRepository<Sequence, String> {
    @Transactional
    @Modifying(flushAutomatically = true, clearAutomatically = true)
    @Query("UPDATE Sequence s SET s.endseq = :number where s.sequenceid = :id")
    public void updateSequence(@Param("number") Integer number, @Param("id") String id);
}
