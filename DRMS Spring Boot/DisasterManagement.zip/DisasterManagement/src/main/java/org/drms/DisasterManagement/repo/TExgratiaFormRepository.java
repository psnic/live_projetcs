package org.drms.DisasterManagement.repo;

import org.drms.DisasterManagement.model.T_exgratia_form;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TExgratiaFormRepository extends JpaRepository<T_exgratia_form, String> {
}
