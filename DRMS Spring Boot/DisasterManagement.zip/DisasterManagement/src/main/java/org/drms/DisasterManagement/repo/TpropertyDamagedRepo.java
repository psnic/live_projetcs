package org.drms.DisasterManagement.repo;

import org.drms.DisasterManagement.model.T_property_damaged;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TpropertyDamagedRepo extends JpaRepository<T_property_damaged, String> {
}
