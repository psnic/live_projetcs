package org.drms.DisasterManagement.repo;

import org.drms.DisasterManagement.model.M_village;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface VillageRepository extends JpaRepository<M_village, String> {
    @Query("SELECT v FROM M_village v WHERE v.blockcode.blockcode = :blockCode")
    List<M_village> getVillagesByBlockCode(@Param("blockCode") int blockCode);
}
