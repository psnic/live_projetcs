package org.drms.DisasterManagement.service;

import lombok.AllArgsConstructor;
import org.drms.DisasterManagement.model.*;
import org.drms.DisasterManagement.repo.*;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
@AllArgsConstructor
public class BdoService {
    private M_infraRepository infraRepository;
    private CalamityRepository calamityRepository;
    private FirRepository firRepository;
    private SequenceRepository sequenceRepository;
    private BlockRepository blockRepository;
    private DistrictRepository districtRepository;
    private TpropertyDamagedRepo tpropertyDamagedRepo;
    private DocumentFirRepo documentFirRepo;
    private VillageRepository villageRepository;
    private NormsRepository normsRepository;
    private DocumentTypeRepository documentTypeRepository;
    private BeneficiaryRepository beneficiaryRepository;
    private TExgratiaFormRepository tExgratiaFormRepository;
    private DocumentBeneficiaryRepository documentBeneficiaryRepository;

    public List<M_infrastructure> getAllInfrastructures() {
        return infraRepository.findAll();
    }

    public List<M_calamity> getAllCalamities() {
        return calamityRepository.findAll();
    }

    public Optional<Sequence> getSequenceById(String id) {
        return sequenceRepository.findById(id);
    }

    public String saveFir(Fir fir) {
        int seqNumber = 0;
        String res = "-1";
        try {
            if (fir.getFir_no() == null || fir.getFir_no().isEmpty()) {
                Optional<Sequence> sequence = sequenceRepository.findById("FIR");
                if (sequence.isPresent()) {
                    String pattern = sequence.get().getPattern();
                    seqNumber = sequence.get().getEndseq();
                    seqNumber = seqNumber + 1;
                    Date calamityDate = fir.getDate_of_calamity_occurence();
                    String year = new SimpleDateFormat("yyyyMMdd").format(calamityDate);
                    String districtshortcode = districtRepository.getDistrictShortNameByBlockCode(fir.getBlockcode().getBlockcode());
                    String generatedFirNo = pattern + districtshortcode + "-" + year + "-" + (seqNumber);
                    fir.setFir_no(generatedFirNo);
                }
            }
            firRepository.save(fir);
            res = fir.getFir_no();
        } catch (Exception e) {
            System.out.println("BdoService|saveFir: " + e.toString());
        }
        return res;
    }

    public String saveExgratiaBeneficiary(Beneficiary beneficiary) {
        String res = "-1";
        int seqNumber = 0;
        try {
            if (beneficiary.getBeneficiary_id() == null || beneficiary.getBeneficiary_id().isEmpty()) {
                Optional<Sequence> sequence = sequenceRepository.findById("BENGR");
                if (sequence.isPresent()) {
                    String pattern = sequence.get().getPattern();
                    seqNumber = sequence.get().getEndseq();
                    seqNumber = seqNumber + 1;
                    String genratedId = pattern + seqNumber;
                    beneficiary.setBeneficiary_id(genratedId);
                }
            }
            beneficiaryRepository.save(beneficiary);
            res = beneficiary.getBeneficiary_id();
        } catch (Exception e) {
            System.out.println("BdoService|saveExgratiaBeneficiary: " + e.toString());
        }
        return res;
    }

    public String savePropertyDamaged(T_property_damaged tPropertyDamaged) {
        String res = "-1";
        int seqNumber = 0;
        try {
            if (tPropertyDamaged.getProperty_damage_id() == null || tPropertyDamaged.getProperty_damage_id().isEmpty()) {
                Optional<Sequence> sequence = sequenceRepository.findById("INFRA");
                if (sequence.isPresent()) {
                    String pattern = sequence.get().getPattern();
                    seqNumber = sequence.get().getEndseq();
                    seqNumber = seqNumber + 1;
                    String generatedId = pattern + seqNumber;
                    tPropertyDamaged.setProperty_damage_id(generatedId);
                    sequenceRepository.updateSequence(seqNumber, "INFRA");
                }
            }
            tpropertyDamagedRepo.save(tPropertyDamaged);
            res = tPropertyDamaged.getProperty_damage_id();
        } catch (Exception e) {
            System.out.println("BdoService|savePropertyDamaged: " + e.toString());
        }
        return res;
    }

    public String saveBeneficiaryExgratia(T_exgratia_form tExgratiaForm){
        String res = "-1";
        int seqNumber = 0;
        try {
            if (tExgratiaForm.getT_exgratia_form_id() == null || tExgratiaForm.getT_exgratia_form_id().isEmpty()) {
                Optional<Sequence> sequence = sequenceRepository.findById("TEF");
                if (sequence.isPresent()) {
                    String pattern = sequence.get().getPattern();
                    seqNumber = sequence.get().getEndseq();
                    seqNumber = seqNumber + 1;
                    String genratedId = pattern + seqNumber;
                    tExgratiaForm.setT_exgratia_form_id(genratedId);
                }
            }
            tExgratiaFormRepository.save(tExgratiaForm);
            res = tExgratiaForm.getT_exgratia_form_id();
        } catch (Exception e) {
            System.out.println("BdoService|saveBeneficiaryExgratia: " + e.toString());
        }
        return res;
    }


    public String saveDocumentFir(Document_fir documentFir) {
        String res = "-1";
        int seqNumber = 0;
        try {
            if (documentFir.getDocumentcode() == null || documentFir.getDocumentcode().isEmpty()) {
                Optional<Sequence> sequence = sequenceRepository.findById("DOCFIR");
                if (sequence.isPresent()) {
                    String pattern = sequence.get().getPattern();
                    seqNumber = sequence.get().getEndseq();
                    seqNumber = seqNumber + 1;
                    String generatedId = pattern + seqNumber;
                    documentFir.setDocumentcode(generatedId);
                    sequenceRepository.updateSequence(seqNumber, "DOCFIR");
                }
            }
            documentFirRepo.save(documentFir);
            res = documentFir.getDocumentcode();
        } catch (Exception e) {
            System.out.println("BdoService|saveDocumentFir: " + e.toString());
        }
        return res;
    }

    public String saveDocumentBeneficiary(Document_beneficiary documentBeneficiary) {
        String res = "-1";
        int seqNumber = 0;
        try {
            if (documentBeneficiary.getBdocumentcode() == null || documentBeneficiary.getBdocumentcode().isEmpty()) {
                Optional<Sequence> sequence = sequenceRepository.findById("DOCBEN");
                if (sequence.isPresent()) {
                    String pattern = sequence.get().getPattern();
                    seqNumber = sequence.get().getEndseq();
                    seqNumber = seqNumber + 1;
                    String generatedId = pattern + seqNumber;
                    documentBeneficiary.setBdocumentcode(generatedId);
                    sequenceRepository.updateSequence(seqNumber, "DOCBEN");
                }
            }
            documentBeneficiaryRepository.save(documentBeneficiary);
            res = documentBeneficiary.getBdocumentcode();
        } catch (Exception e) {
            System.out.println("BdoService|saveDocumentBeneficiary: " + e.toString());
        }
        return res;
    }

    public List<Fir> getAllFir() {
        return firRepository.findAll();
    }

    public List<M_village> getVillageFromBlockCode(int blockCode) {
        return villageRepository.getVillagesByBlockCode(blockCode);
    }

    public List<Date> getAllDatesFromFir() {
        return firRepository.getAllDistinctCalamityOccurrenceDates();
    }

    public List<Fir> getAllFirFromDate(Date date) {
        return firRepository.getAllFirFromDate(date);
    }

    public List<Norms> getExgratiaNorms() {
        return normsRepository.getAllExgratiaNorms();
    }

    public List<String> getDocumentTypeByNormCode(int norm_code) {
        return documentTypeRepository.getDocumentsByNormCode(norm_code);
    }

    public List<Object[]> getAssistedBeneficiaries() {
        return beneficiaryRepository.getAssistedBeneficiaries();
    }

    public M_calamity getCalamityByFir(String fir_no){
        return firRepository.getCalamityByFir(fir_no);
    }

    public List<Fir> getDistinctFirNo(){
        return firRepository.getDistinctFirNo();
    }
}
