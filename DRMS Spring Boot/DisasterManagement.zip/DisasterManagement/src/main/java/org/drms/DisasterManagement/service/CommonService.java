package org.drms.DisasterManagement.service;


import lombok.AllArgsConstructor;
import org.drms.DisasterManagement.model.MT_Userlogin;
import org.drms.DisasterManagement.repo.FirRepository;
import org.drms.DisasterManagement.repo.UserLoginRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class CommonService {
	
	@Autowired
	private UserLoginRepo userLoginRepo;
	
	public MT_Userlogin getUserByUsername(String username) {
		try {
			return userLoginRepo.findByUsername(username).get();
		} catch (Exception e) {
			throw new RuntimeException("Cannot Fetch User");
		}
	}

}
