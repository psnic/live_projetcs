package org.drms.DisasterManagement.service;


import org.drms.DisasterManagement.model.MT_Userlogin;
import org.drms.DisasterManagement.repo.UserLoginRepo;
import org.drms.DisasterManagement.mapper.UserLoginUserDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import java.util.Optional;

public class UserLoginDetailsService implements UserDetailsService {

	@Autowired
	private UserLoginRepo userLoginRepo;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		System.out.println("USERID:: "+ username);
		Optional<MT_Userlogin> userLogin = userLoginRepo.findByUsername(username);
		System.out.println("OBJECT:: "+ userLogin.get().toString());
		return userLogin.map(UserLoginUserDetails::new)
				.orElseThrow(() -> new UsernameNotFoundException("Username Not Found"));

	}
}
