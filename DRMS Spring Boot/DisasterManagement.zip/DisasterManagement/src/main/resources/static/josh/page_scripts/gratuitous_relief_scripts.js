$(document).ready(function () {

    var csrfToken = $("meta[name='_csrf']").attr("content");
    var csrfHeader = $("meta[name='_csrf_header']").attr("content");

    populateSelectOptionsAndFields($('#assistanceSelect').val());

    // Bind onchange event to populate select options and fields
    $('#assistanceSelect').change(function () {
        var selectedValue = $(this).val();
        populateSelectOptionsAndFields(selectedValue);
        fetchDocumentTypes(selectedValue);
    });

    function toggleGrievousContainer() {
        var radioN1 = document.getElementById('no1');
        var grievousContainer1 = document.getElementById('grievousContainer1');
        var grievousFooter1 = document.getElementById('grievousFooter1');

        var radioN2 = document.getElementById('no2');
        var grievousContainer2 = document.getElementById('grievousContainer2');
        var grievousFooter2 = document.getElementById('grievousFooter2');

        if (radioN1.checked) {
            grievousContainer1.classList.remove('d-none');
            grievousFooter1.classList.remove('d-none');
        } else {
            grievousContainer1.classList.add('d-none');
            grievousFooter1.classList.add('d-none');
        }

        if (radioN2.checked) {
            grievousContainer2.classList.remove('d-none');
            grievousFooter2.classList.remove('d-none');
        } else {
            grievousContainer2.classList.add('d-none');
            grievousFooter2.classList.add('d-none');
        }
    }

    // Add an event listener to the radio buttons
    var radioYes1 = document.getElementById('yes1');
    var radioNo1 = document.getElementById('no1');
    var radioYes2 = document.getElementById('yes2');
    var radioNo2 = document.getElementById('no2');

    radioYes1.addEventListener('change', toggleGrievousContainer);
    radioNo1.addEventListener('change', toggleGrievousContainer);
    radioYes2.addEventListener('change', toggleGrievousContainer);
    radioNo2.addEventListener('change', toggleGrievousContainer);

    // Call the function initially to set the initial state
    toggleGrievousContainer();

    $('#dataTable').DataTable({});

    $('#dateSelect').change(function () {
        $.confirm({
            content: function () {
                var self = this;
                return $.ajax({
                    url: 'getallfirfromdate',
                    data: 'date=' + $('#dateSelect').val(),
                    method: 'get'
                }).done(function (response) {
                    console.log(response);
                    var markup = "<option value=''>--Select--</option>"
                    for (var i = 0; i < response.length; i++) {
                        markup += "<option value=" + response[i].fir_no + ">" + response[i].fir_no + "</option>";
                    }
                    $('#firSelect').html(markup);
                    self.close();
                }).fail(function () {
                    self.setContent('Something went wrong.');
                });
            }
        });
    });

    //Save For Norm Code - 1
    $("#exgratiaForm1").submit(function (e) {
        e.preventDefault();
        var norm = $('#assistanceSelect').val();
        var fir = $('#firSelect').val();
        var finyear = $('#financialYear').val();
        var beneficiaryName = $('#inputBeneficiaryName1').val();
        var assistanceSelect = document.getElementById('assistanceSelect');
        var amount = $('#inputAmountPayable1').val();
        var selectedOption = assistanceSelect.options[assistanceSelect.selectedIndex].text;
        var formData = new FormData($(this)[0]);
        formData.append('normSelect', norm);
        formData.append('fir_no', fir);
        formData.append('fin_year', finyear);
        $.confirm({
            content: function () {
                var self = this;
                return $.ajax({
                    method: 'POST',
                    url: "saveexgratia",
                    data: formData,
                    processData: false,
                    contentType: false,
                    beforeSend: function (xhr) {
                        xhr.setRequestHeader(csrfHeader, csrfToken);
                    }
                }).done(function (response) {
                    if (response !== '-1') {
                        self.setTitle("Success");
                        self.setContent("Details Saved Successfully");
                        // Add a new row to the table with the saved data
                        var newRow = $("<tr>");
                        newRow.append("<td class='text-center'>" + ($('#dataTable tbody tr').length + 1) + "</td>");
                        newRow.append("<td>" + beneficiaryName + "</td>");
                        newRow.append("<td>" + selectedOption + "</td>");
                        newRow.append("<td>" + amount + "</td>");

                        $('#dataTable tbody').append(newRow);

                        // Scroll down to the table
                        $('html, body').animate({
                            scrollTop: $("#dataTable").offset().top
                        }, 1000);
                    } else {
                        self.setTitle("Failed");
                    }
                }).fail(function () {
                    self.setTitle('Something went wrong.');
                });
            },
            buttons: {
                close: {
                    action: function () {
                        $("#exgratiaForm1").trigger("reset");
                    }
                }
            }
        });
    });

    //Save For Norm Code - 2
    $("#exgratiaForm2").submit(function (e) {
        e.preventDefault();
        var norm = $('#assistanceSelect').val();
        var fir = $('#firSelect').val();
        var finyear = $('#financialYear').val();
        var beneficiaryName = $('#inputBeneficiaryName2').val();
        var assistanceSelect = document.getElementById('assistanceSelect');
        var amount = $('#inputAmountPayable2').val();
        var selectedOption = assistanceSelect.options[assistanceSelect.selectedIndex].text;
        var formData = new FormData($(this)[0]);
        formData.append('normSelect', norm);
        formData.append('fir_no', fir);
        formData.append('fin_year', finyear);
        $.confirm({
            content: function () {
                var self = this;
                return $.ajax({
                    method: 'POST',
                    url: "saveexgratia",
                    data: formData,
                    processData: false,
                    contentType: false,
                    beforeSend: function (xhr) {
                        xhr.setRequestHeader(csrfHeader, csrfToken);
                    }
                }).done(function (response) {
                    if (response !== '-1') {
                        self.setTitle("Success");
                        self.setContent("Details Saved Successfully");
                        // Add a new row to the table with the saved data
                        var newRow = $("<tr>");
                        newRow.append("<td class='text-center'>" + ($('#dataTable tbody tr').length + 1) + "</td>");
                        newRow.append("<td>" + beneficiaryName + "</td>");
                        newRow.append("<td>" + selectedOption + "</td>");
                        newRow.append("<td>" + amount + "</td>");

                        $('#dataTable tbody').append(newRow);

                        // Scroll down to the table
                        $('html, body').animate({
                            scrollTop: $("#dataTable").offset().top
                        }, 1000);
                    } else {
                        self.setTitle("Failed");
                    }
                }).fail(function () {
                    self.setTitle('Something went wrong.');
                });
            },
            buttons: {
                close: {
                    action: function () {
                        $("#exgratiaForm2").trigger("reset");
                    }
                }
            }
        });
    });

    //Save For Norm Code - 3
    $("#exgratiaForm3").submit(function (e) {
        e.preventDefault();
        var norm = $('#assistanceSelect').val();
        var fir = $('#firSelect').val();
        var finyear = $('#financialYear').val();
        var beneficiaryName = $('#inputBeneficiaryName3').val();
        var assistanceSelect = document.getElementById('assistanceSelect');
        var amount = $('#inputAmountPayable3').val();
        var selectedOption = assistanceSelect.options[assistanceSelect.selectedIndex].text;
        var formData = new FormData($(this)[0]);
        formData.append('normSelect', norm);
        formData.append('fir_no', fir);
        formData.append('fin_year', finyear);
        $.confirm({
            content: function () {
                var self = this;
                return $.ajax({
                    method: 'POST',
                    url: "saveexgratia",
                    data: formData,
                    processData: false,
                    contentType: false,
                    beforeSend: function (xhr) {
                        xhr.setRequestHeader(csrfHeader, csrfToken);
                    }
                }).done(function (response) {
                    if (response !== '-1') {
                        self.setTitle("Success");
                        self.setContent("Details Saved Successfully");
                        // Add a new row to the table with the saved data
                        var newRow = $("<tr>");
                        newRow.append("<td class='text-center'>" + ($('#dataTable tbody tr').length + 1) + "</td>");
                        newRow.append("<td>" + beneficiaryName + "</td>");
                        newRow.append("<td>" + selectedOption + "</td>");
                        newRow.append("<td>" + amount + "</td>");

                        $('#dataTable tbody').append(newRow);

                        // Scroll down to the table
                        $('html, body').animate({
                            scrollTop: $("#dataTable").offset().top
                        }, 1000);
                    } else {
                        self.setTitle("Failed");
                    }
                }).fail(function () {
                    self.setTitle('Something went wrong.');
                });
            },
            buttons: {
                close: {
                    action: function () {
                        $("#exgratiaForm3").trigger("reset");
                    }
                }
            }
        });
    });

    //Save For Norm Code - 4
    $("#exgratiaForm4").submit(function (e) {
        e.preventDefault();
        var norm = $('#assistanceSelect').val();
        var fir = $('#firSelect').val();
        var finyear = $('#financialYear').val();
        var beneficiaryName = $('#inputBeneficiaryName4').val();
        var assistanceSelect = document.getElementById('assistanceSelect');
        var amount = $('#inputAmountPayable4').val();
        var selectedOption = assistanceSelect.options[assistanceSelect.selectedIndex].text;
        var formData = new FormData($(this)[0]);
        formData.append('normSelect', norm);
        formData.append('fir_no', fir);
        formData.append('fin_year', finyear);
        $.confirm({
            content: function () {
                var self = this;
                return $.ajax({
                    method: 'POST',
                    url: "saveexgratia",
                    data: formData,
                    processData: false,
                    contentType: false,
                    beforeSend: function (xhr) {
                        xhr.setRequestHeader(csrfHeader, csrfToken);
                    }
                }).done(function (response) {
                    if (response !== '-1') {
                        self.setTitle("Success");
                        self.setContent("Details Saved Successfully");
                        // Add a new row to the table with the saved data
                        var newRow = $("<tr>");
                        newRow.append("<td class='text-center'>" + ($('#dataTable tbody tr').length + 1) + "</td>");
                        newRow.append("<td>" + beneficiaryName + "</td>");
                        newRow.append("<td>" + selectedOption + "</td>");
                        newRow.append("<td>" + amount + "</td>");

                        $('#dataTable tbody').append(newRow);

                        // Scroll down to the table
                        $('html, body').animate({
                            scrollTop: $("#dataTable").offset().top
                        }, 1000);
                    } else {
                        self.setTitle("Failed");
                    }
                }).fail(function () {
                    self.setTitle('Something went wrong.');
                });
            },
            buttons: {
                close: {
                    action: function () {
                        $("#exgratiaForm4").trigger("reset");
                    }
                }
            }
        });
    });

    //Save For Norm Code - 5
    $("#exgratiaForm5").submit(function (e) {
        e.preventDefault();
        var norm = $('#assistanceSelect').val();
        var fir = $('#firSelect').val();
        var finyear = $('#financialYear').val();
        var beneficiaryName = $('#inputBeneficiaryName5').val();
        var assistanceSelect = document.getElementById('assistanceSelect');
        var amount = $('#inputAmountPayable5').val();
        var selectedOption = assistanceSelect.options[assistanceSelect.selectedIndex].text;
        var formData = new FormData($(this)[0]);
        formData.append('normSelect', norm);
        formData.append('fir_no', fir);
        formData.append('fin_year', finyear);
        $.confirm({
            content: function () {
                var self = this;
                return $.ajax({
                    method: 'POST',
                    url: "saveexgratia",
                    data: formData,
                    processData: false,
                    contentType: false,
                    beforeSend: function (xhr) {
                        xhr.setRequestHeader(csrfHeader, csrfToken);
                    }
                }).done(function (response) {
                    if (response !== '-1') {
                        self.setTitle("Success");
                        self.setContent("Details Saved Successfully");
                        // Add a new row to the table with the saved data
                        var newRow = $("<tr>");
                        newRow.append("<td class='text-center'>" + ($('#dataTable tbody tr').length + 1) + "</td>");
                        newRow.append("<td>" + beneficiaryName + "</td>");
                        newRow.append("<td>" + selectedOption + "</td>");
                        newRow.append("<td>" + amount + "</td>");

                        $('#dataTable tbody').append(newRow);

                        // Scroll down to the table
                        $('html, body').animate({
                            scrollTop: $("#dataTable").offset().top
                        }, 1000);
                    } else {
                        self.setTitle("Failed");
                    }
                }).fail(function () {
                    self.setTitle('Something went wrong.');
                });
            },
            buttons: {
                close: {
                    action: function () {
                        $("#exgratiaForm5").trigger("reset");
                    }
                }
            }
        });
    });

    //Save For Norm Code - 6
    $("#exgratiaForm6").submit(function (e) {
        e.preventDefault();
        var norm = $('#assistanceSelect').val();
        var fir = $('#firSelect').val();
        var finyear = $('#financialYear').val();
        var beneficiaryName = $('#inputBeneficiaryName6').val();
        var assistanceSelect = document.getElementById('assistanceSelect');
        var amount = $('#inputAmountPayable6').val();
        var selectedOption = assistanceSelect.options[assistanceSelect.selectedIndex].text;
        var formData = new FormData($(this)[0]);
        formData.append('normSelect', norm);
        formData.append('fir_no', fir);
        formData.append('fin_year', finyear);
        $.confirm({
            content: function () {
                var self = this;
                return $.ajax({
                    method: 'POST',
                    url: "saveexgratia",
                    data: formData,
                    processData: false,
                    contentType: false,
                    beforeSend: function (xhr) {
                        xhr.setRequestHeader(csrfHeader, csrfToken);
                    }
                }).done(function (response) {
                    if (response !== '-1') {
                        self.setTitle("Success");
                        self.setContent("Details Saved Successfully");
                        // Add a new row to the table with the saved data
                        var newRow = $("<tr>");
                        newRow.append("<td class='text-center'>" + ($('#dataTable tbody tr').length + 1) + "</td>");
                        newRow.append("<td>" + beneficiaryName + "</td>");
                        newRow.append("<td>" + selectedOption + "</td>");
                        newRow.append("<td>" + amount + "</td>");

                        $('#dataTable tbody').append(newRow);

                        // Scroll down to the table
                        $('html, body').animate({
                            scrollTop: $("#dataTable").offset().top
                        }, 1000);
                    } else {
                        self.setTitle("Failed");
                    }
                }).fail(function () {
                    self.setTitle('Something went wrong.');
                });
            },
            buttons: {
                close: {
                    action: function () {
                        $("#exgratiaForm6").trigger("reset");
                    }
                }
            }
        });
    });

    //Save For Norm Code - 7
    $("#exgratiaForm7").submit(function (e) {
        e.preventDefault();
        var norm = $('#assistanceSelect').val();
        var fir = $('#firSelect').val();
        var finyear = $('#financialYear').val();
        var beneficiaryName = $('#inputBeneficiaryName7').val();
        var assistanceSelect = document.getElementById('assistanceSelect');
        var amount = $('#inputAmountPayable7').val();
        var selectedOption = assistanceSelect.options[assistanceSelect.selectedIndex].text;
        var formData = new FormData($(this)[0]);
        formData.append('normSelect', norm);
        formData.append('fir_no', fir);
        formData.append('fin_year', finyear);
        $.confirm({
            content: function () {
                var self = this;
                return $.ajax({
                    method: 'POST',
                    url: "saveexgratia",
                    data: formData,
                    processData: false,
                    contentType: false,
                    beforeSend: function (xhr) {
                        xhr.setRequestHeader(csrfHeader, csrfToken);
                    }
                }).done(function (response) {
                    if (response !== '-1') {
                        self.setTitle("Success");
                        self.setContent("Details Saved Successfully");
                        // Add a new row to the table with the saved data
                        var newRow = $("<tr>");
                        newRow.append("<td class='text-center'>" + ($('#dataTable tbody tr').length + 1) + "</td>");
                        newRow.append("<td>" + beneficiaryName + "</td>");
                        newRow.append("<td>" + selectedOption + "</td>");
                        newRow.append("<td>" + amount + "</td>");

                        $('#dataTable tbody').append(newRow);

                        // Scroll down to the table
                        $('html, body').animate({
                            scrollTop: $("#dataTable").offset().top
                        }, 1000);
                    } else {
                        self.setTitle("Failed");
                    }
                }).fail(function () {
                    self.setTitle('Something went wrong.');
                });
            },
            buttons: {
                close: {
                    action: function () {
                        $("#exgratiaForm7").trigger("reset");
                    }
                }
            }
        });
    });

});

function populateSelectOptionsAndFields(selectedValue) {
    // Fetch norms data and update select options
    $.ajax({
        url: 'exgratianorms',
        method: 'GET',
        dataType: 'json',
        success: function (normsData) {
            console.log(normsData);
            var selectedNorm = null;
            var formTitleText = "";
            var selectOptionsMarkup = "<option value='' selected disabled>---Assistances For Gratuitous Relief---</option>";
            for (var i = 0; i < normsData.length; i++) {
                var norm = normsData[i];
                var selectText = norm.description + ' ' + norm.losstype;
                if (norm.option !== 'N.A' && norm.option !== 'NA') {
                    selectText += ' ' + norm.option;
                }
                selectOptionsMarkup += '<option value="' + norm.norm_code + '" class="text-capitalize">' + selectText + '</option>';
                // Check if this is the selected norm
                if (norm.norm_code === parseInt(selectedValue)) {
                    selectedNorm = norm;
                    formTitleText = selectText;
                }
                $('#assistanceSelect option[value=' + norm[0] + ']').attr('selected', 'selected');
            }

            $('#assistanceSelect').html(selectOptionsMarkup);
            // Update inputAmountPayable and toggle container visibility
            if (selectedNorm) {
                for (var i = 1; i <= 7; i++) {
                    if (i === parseInt(selectedValue)) {
                        $('#exGratia' + i + 'Container').removeClass('d-none');
                        $('#formTitle' + i).html(formTitleText);
                        $('#inputAmountPayable' + i).val(selectedNorm.value);
                    } else {
                        $('#exGratia' + i + 'Container').addClass('d-none');
                    }
                }
            }
            $('#assistanceSelect').val(selectedValue);
        },
        error: function () {
            console.error('Error fetching norms data.');
        }
    });
}

function fetchDocumentTypes(normCode) {
    // Make an AJAX request to fetch required document types based on normCode
    $.ajax({
        url: 'getdocumenttypesforbeneficiary',
        method: 'GET',
        data: { norm_code: normCode },
        success: function (documentTypes) {
            console.log(documentTypes);
            var uploadFieldsMarkup = '';
            for (var i = 0; i < documentTypes.length; i++) {
                var documentType = documentTypes[i];
                uploadFieldsMarkup +=
                    '<div class="form-group row mt-4">' +
                    '<label for="fileInput' + i + '" class="form-label text-capitalize col-md-4"><b>Upload ' + documentType + '&nbsp;<i class="fa-solid fa-star-of-life fa-beat-fade fa-2xs" style="color: #ff4747;"></i></b></label>' +
                    '<div class="col-md-8">' +
                    '<input class="form-control" id="fileInput' + i + '" type="file" class="form-control" name="files">' +
                    //                                    '<input type="file" id="fileInput' + i + '" class="form-control" name="files" accept="image/png, image/jpeg" required style="display:none;">' +
                    '</div>' +
                    '</div>';
            }
            switch (normCode) {
                case '1':
                    $('#dynamicUploadFieldsContainer1').html(uploadFieldsMarkup);
                    break;
                case '2':
                    $('#dynamicUploadFieldsContainer2').html(uploadFieldsMarkup);
                    break;
                case '3':
                    $('#dynamicUploadFieldsContainer3').html(uploadFieldsMarkup);
                    break;
                case '4':
                    $('#dynamicUploadFieldsContainer4').html(uploadFieldsMarkup);
                    break;
                case '5':
                    $('#dynamicUploadFieldsContainer5').html(uploadFieldsMarkup);
                    break;
                case '6':
                    $('#dynamicUploadFieldsContainer6').html(uploadFieldsMarkup);
                    break;
                case '7':
                    $('#dynamicUploadFieldsContainer7').html(uploadFieldsMarkup);
                    break;
                // Add more cases for other normCodes if needed
                default:
                    break;
            }
        }
    });
}