var csrfHeader = $("meta[name='_csrf_header']").attr("content");
var csrfToken = $("meta[name='_csrf']").attr("content");
$(document).ready(function () {
    var dataTableInitialized = false;
    $("#firSelect").on("change", function () {
        var selectedFir = $(this).val();
        if (selectedFir !== "") {
            $.ajax({
                url: "getexgratiafromfir",
                method: "GET",
                data: "firNo=" + selectedFir,
                success: function (res) {
                    var response = JSON.parse(res)
                    console.log(response);
                    var uploadFieldsMarkup = '';
                    var beneficiary = response[0];
                    var document = response[1];
                    $("#tableBody").empty();
                    for (var i = 0; i < beneficiary.beneficiaries.length; i++) {
                        var newRow = '<tr>' +
                                '<td>' + (i + 1) + '</td>' +
                                '<td>' + beneficiary.beneficiaries[i].beneficiaryName + '</td>' +
                                '<td>' + beneficiary.beneficiaries[i].village + '</td>' +
                                '<td>' + beneficiary.beneficiaries[i].amount + '</td>' +
                                '<td>' + beneficiary.beneficiaries[i].assistance + '</td>' +
                                '<td>' + beneficiary.beneficiaries[i].remarks + '</td>' +
                                '</tr>';
                        $("#tableBody").append(newRow);
                    }
                    for (var i = 0; i < document.documents.length; i++) {
                        uploadFieldsMarkup +=
                                '<div class="form-group row mt-4">' +
                                '<label for="fileInput' + i + '" class="form-label text-capitalize col-md-4"><b>Upload ' + document.documents[i].document_name + '&nbsp;<i class="fa-solid fa-star-of-life fa-beat-fade fa-2xs" style="color: #ff4747;"></i></b></label>' +
                                '<div class="col-md-8">' +
                                '<input class="form-control dynamicFileInput" id="fileInput' + i + '" type="file" required name="files" accept="image/jpeg">' +
                                '<ol class="breadcrumb mb-2">' +
                                '<li class="breadcrumb-item active text-danger">In JPG/JPEG Format</li>' +
                                '</ol>' +
//                                    '<input type="file" id="fileInput' + i + '" class="form-control" name="files" accept="image/png, image/jpeg" required style="display:none;">' +
                                '</div>' +
                                '</div>';
                    }
                    $('#dynamicUploadFieldsContainer1').html(uploadFieldsMarkup);
                    // Initialize DataTable only if not already initialized
                    if (!dataTableInitialized) {
                        $('#reportTable').DataTable();
                        dataTableInitialized = true;
                    }

                    $("#tableContainer").removeClass("d-none");
                },
                error: function (xhr, textStatus, errorThrown) {
                    console.error("Error fetching table data:", errorThrown);
                }
            });
        } else {
            $("#tableContainer").addClass("d-none");
        }
    });

    $("#documentReportForm").submit(function (e) {
        e.preventDefault();
        var successFlag = false; // Flag to track success
        var selectedFir = $("#firSelect").val();

        $.confirm({
            title: 'Forward Statement Of Proposal',
            columnClass: 'medium', // Adjust the column width if needed
            content:
                    '<div class="custom-dialog">' +
                    '<h6>Are you sure you want to forward this statement of proposal with FIR No: <b>' + selectedFir + ' </b> to DC?</h6>' +
                    '<div class="form-group mb-2">' +
                    '<label for="remarks" class="mt-3"><b>Remarks before forwarding:</b></label>' +
                    '<textarea rows="2" id="remarks" class="form-control mt-2"></textarea>' +
                    '</div>' +
                    '</div>',
            buttons: {
                forwardRep: {
                    text: 'Forward',
                    btnClass: 'btn-success',
                    action: function () {
                        $.confirm({
                            content: function () {
                                var self = this;
                                var formData = new FormData();
                                $(".dynamicFileInput").each(function () {
                                    var files = $(this)[0].files;
                                    // Append each selected file to the formData
                                    for (var i = 0; i < files.length; i++) {
                                        formData.append("files", files[i]);
                                    }
                                });
                                var population = $("#inputNoPopulation").val();
                                var village = $("#inputNoVillage").val();
                                var family = $("#inputNoFamily").val();
                                var remarks = $("#remarks").val();
                                formData.append("firNo", selectedFir);
                                formData.append("remarks", remarks);
                                formData.append("no_of_population_affected", population);
                                formData.append("no_of_family_affected", family);
                                formData.append("no_of_village_affected", village);
                                return $.ajax({
                                    url: './forwardreport.htm',
                                    data: formData,
                                    method: 'POST',
                                    processData: false,
                                    contentType: false,
                                    beforeSend: function (xhr) {
                                        xhr.setRequestHeader(csrfHeader, csrfToken);
                                    }
                                }).done(function (response) {
                                    console.log(response);
                                    self.setTitle(response.name);
                                    if (response === '-1') {
                                        self.setTitle('Failed!');
                                        self.setContent('Failed to forward statement of proposal.');
                                    } else {
                                        self.setTitle('Success!');
                                        self.setContent('Statement of proposal successfully forwarded.');
                                        successFlag = true; // Set success flag
                                    }
                                }).fail(function () {
                                    self.setContent('Something went wrong.');
                                });
                            },
                            buttons: {
                                close: function () {
                                    if (!successFlag) {
                                        $.alert('Something went wrong');
                                    } else {
                                        window.location.reload();
                                    }
                                }
                            }
                        });
                    }
                },
                cancel: function () {
                    $.alert('Report Not Forwarded');
                }
            }
        });
    });
});