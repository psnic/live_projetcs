const checkCaptcha = () => {
	const captcha = document.getElementById("captcha");
	const hiddenCaptcha = document.getElementById("hiddenCaptcha");

	if (captcha.value != hiddenCaptcha.value) {
		captcha.value = "";

		$.alert("Captcha does not match. Please try again.")
	}
};

const reloadCaptcha = () => {
	const realCaptcha = document.getElementById("realCaptcha");
	const hiddenCaptcha = document.getElementById("hiddenCaptcha");
	const iconElement = document.getElementById('captchaIcon');
	$.ajax({
		url: "/refresh-captcha",
		method: "GET",
	})
		.done(function(response) {
			hiddenCaptcha.value = response.hiddenCaptcha;
			realCaptcha.src =
				"data:realCaptcha/jpg;base64," + response.realCaptcha;
			iconElement.classList.toggle('selected');

		})
		.fail(function() {
			self.setContent("Something went wrong.");
		});
};

$(document).ready(function() {

	/*get Captcha from form and modal*/
	const captcha = document.getElementById("captcha")
	const hiddenCaptcha = document.getElementById("hiddenCaptcha")
	const realCaptcha = document.getElementById("realCaptcha")
	const captchaModal = document.getElementById("captchaModal")
	const hiddenCaptchaModal = document.getElementById("hiddenCaptchaModal")
	const realCaptchaModal = document.getElementById("realCaptchaModal")
	/*end*/

	/*set in Modal*/
	hiddenCaptchaModal.value = hiddenCaptcha.value
	realCaptchaModal.src = "data:realCaptcha/jpg;base64," + realCaptcha.value;
	/*end*/




	doLogin = () => {
		const captchaCheck = document.getElementById("captchaModal")
		//		console.log(captchaCheck.value)

		if (captchaCheck.value === null || captchaCheck.value === "") {
			$.alert("Please Enter Captcha", "Verification Required")
		} else {
			document.getElementById("loginForm").submit();
		}

	}

});